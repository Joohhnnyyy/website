import streamlit as st
import pandas as pd
import numpy as np
from datetime import datetime
import pickle

# Load models and scaler
@st.cache_resource
def load_models():
    with open('weather_models.pkl', 'rb') as f:
        models = pickle.load(f)
    with open('weather_scaler.pkl', 'rb') as f:
        scaler = pickle.load(f)
    return models, scaler

def prepare_features(date):
    """Prepare features from date input"""
    # Basic features only (matching the training data)
    features = {
        'Year': date.year,
        'Month': date.month,
        'Day': date.day
    }
    return pd.DataFrame([features])

def format_prediction(param, value):
    units = {
        'Temperature at 2 meters (c)': '°C',
        'Precipitation Corrected (mm/day)': 'mm/day',
        'Specific Humidity at 2 Meters (g/kg)': 'g/kg',
        'Wind Speed at 2 Meters (m/s)': 'm/s',
        'Root Zone Soil Wetness': ''
    }
    return f"{value:.2f} {units.get(param, '')}"

# Streamlit UI
st.title('Weather Prediction System')

try:
    models, scaler = load_models()
    
    # Date input
    selected_date = st.date_input(
        "Select a date",
        min_value=datetime(1900, 1, 1),
        max_value=datetime(2100, 12, 31)
    )
    
    if st.button('Predict Weather'):
        features = prepare_features(selected_date)
        features_scaled = scaler.transform(features)
        
        # Make predictions
        predictions = {}
        for col in models:
            value = models[col].predict(features_scaled)[0]
            if col == 'Precipitation Corrected (mm/day)':
                value = max(0, value)
            predictions[col] = value
        
        # Display results in a nice format
        st.subheader('Predicted Weather Parameters')
        col1, col2 = st.columns(2)
        
        for i, (param, value) in enumerate(predictions.items()):
            if i % 2 == 0:
                col1.metric(param, format_prediction(param, value))
            else:
                col2.metric(param, format_prediction(param, value))

except Exception as e:
    st.error(f"An error occurred: {e}")