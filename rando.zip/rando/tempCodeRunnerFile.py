from flask import Flask, request, jsonify
import pickle
import pandas as pd
import numpy as np

app = Flask(__name__)

# Load the pre-trained model and transformers
model = pickle.load(open("Final_Fertilizer_model.pkl", "rb"))
ct = pickle.load(open("column_transformer", "rb"))  # Load column transformer
sc = pickle.load(open("scaler.pkl", "rb"))  # Load scaler

def predict_fertilizer(Temperature, Humidity, Moisture, Soil_Type, Crop_Type, Nitrogen, Phosphorous, Potassium):
    user_input = pd.DataFrame({
        'Temparature': [Temperature],
        'Humidity ': [Humidity],
        'Moisture': [Moisture],
        'Soil Type': [Soil_Type],  # Keeping it as a string
        'Crop Type': [Crop_Type],  # Keeping it as a string
        'Nitrogen': [Nitrogen],
        'Phosphorous': [Phosphorous],
        'Potassium': [Potassium]
    })

    # Encode categorical data
    user_input_encoded = ct.transform(user_input)

    # Scale the features
    user_input_scaled = sc.transform(user_input_encoded)

    # Add noise (optional, if required in your model training)
    noise_factor_user = 0.3
    user_input_noisy = user_input_scaled + noise_factor_user * np.random.normal(loc=0.0, scale=1.0, size=user_input_scaled.shape)

    # Make prediction
    prediction = model.predict(user_input_noisy)

    return prediction[0]

@app.route('/submit', methods=['POST'])
def submit():
    try:
        data = request.json

        # Extract input values
        temperature = float(data['temperature'])
        humidity = float(data['humidity'])
        moisture = float(data['moisture'])
        soil_type = str(data['soil_type'])  # Convert to string
        crop_type = str(data['crop_type'])  # Convert to string
        nitrogen = float(data['nitrogen'])
        phosphorous = float(data['phosphorous'])
        potassium = float(data['potassium'])

        # Get prediction
        predicted_fertilizer = predict_fertilizer(temperature, humidity, moisture, soil_type, crop_type, nitrogen, phosphorous, potassium)

        return jsonify({'prediction': predicted_fertilizer})
    
    except Exception as e:
        return jsonify({'error': str(e)})

if __name__ == '__main__':
    app.run(debug=True)
