// Get DOM elements
const calendarContainer = document.getElementById('calendar');
const selectedDateElement = document.getElementById('selected-date');
const monthSelect = document.getElementById('month-select');
const yearSelect = document.getElementById('year-select');
const prevButton = document.getElementById('prev-month');
const nextButton = document.getElementById('next-month');

// Get current date
const currentDate = new Date();
let currentMonth = currentDate.getMonth();
let currentYear = currentDate.getFullYear();

// Weekdays & Months Arrays
const weekdays = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
const months = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
];

// Populate Month Dropdown
months.forEach((month, index) => {
    let option = document.createElement("option");
    option.value = index;
    option.textContent = month;
    monthSelect.appendChild(option);
});

// Populate Year Dropdown (1900 - 2100)
for (let year = 1900; year <= 2100; year++) {
    let option = document.createElement("option");
    option.value = year;
    option.textContent = year;
    yearSelect.appendChild(option);
}

// Set dropdown values to current month/year
monthSelect.value = currentMonth;
yearSelect.value = currentYear;

// Function to Generate Calendar
function generateCalendar(month, year) {
    calendarContainer.innerHTML = ""; // Clear previous calendar

    // Create weekday headers
    weekdays.forEach(day => {
        const header = document.createElement('div');
        header.textContent = day;
        header.classList.add("calendar-header");
        calendarContainer.appendChild(header);
    });

    // Get first day & total days in the month
    const firstDay = new Date(year, month, 1).getDay();
    const totalDays = new Date(year, month + 1, 0).getDate();

    // Empty cells before the first day
    for (let i = 0; i < firstDay; i++) {
        const emptyCell = document.createElement('div');
        emptyCell.classList.add("empty-cell");
        calendarContainer.appendChild(emptyCell);
    }

    // Create days of the month
    for (let day = 1; day <= totalDays; day++) {
        const dayCell = document.createElement('div');
        dayCell.textContent = day;
        dayCell.classList.add("calendar-day");
        dayCell.addEventListener('click', () => selectDate(day, month, year));
        calendarContainer.appendChild(dayCell);
    }
}

// Function to Display Selected Date
function selectDate(day, month, year) {
    const selectedDate = `${weekdays[new Date(year, month, day).getDay()]}, ${months[month]} ${day}, ${year}`;
    selectedDateElement.textContent = `You selected: ${selectedDate}`;
}

// Function for Next Month
function nextMonth() {
    if (currentMonth === 11) {
        currentMonth = 0;
        currentYear++;
    } else {
        currentMonth++;
    }
    updateControls();
}

// Function for Previous Month
function prevMonth() {
    if (currentMonth === 0) {
        currentMonth = 11;
        currentYear--;
    } else {
        currentMonth--;
    }
    updateControls();
}

// Update dropdowns and regenerate calendar
function updateControls() {
    monthSelect.value = currentMonth;
    yearSelect.value = currentYear;
    generateCalendar(currentMonth, currentYear);
}

// Event Listeners
monthSelect.addEventListener("change", () => {
    currentMonth = parseInt(monthSelect.value);
    generateCalendar(currentMonth, currentYear);
});

yearSelect.addEventListener("change", () => {
    currentYear = parseInt(yearSelect.value);
    generateCalendar(currentMonth, currentYear);
});

prevButton.addEventListener("click", prevMonth);
nextButton.addEventListener("click", nextMonth);

// Initial Calendar Load
generateCalendar(currentMonth, currentYear);
